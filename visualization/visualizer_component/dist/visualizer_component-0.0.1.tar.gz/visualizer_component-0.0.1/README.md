# 3DTile rendering component using giro3D

this component runs as standalone server to render the 3Dtileset for the surface rendering dataset. 


## build instructions
```
npm run build

npm run start
```


